# marks-arashi-schooner
FoundryVTT Content Module

![the latest version zip](https://img.shields.io/github/downloads/MarkPearce/marks-arashi-schooner/latest/marks-arashi-schooner.zip)

This schooner is inspired by the blueprints of the Schooner Ernestina-Morrissey  built in 1894 at the James and Tarr Shipyard for the Gloucester fishing fleet. As well as being a fishing vessel, over the course of her long history she sailed to within 600 miles of the North Pole, and later brought immigrants to the U.S.  Returned to the US in 1982 as a gift from the newly independent Cape Verdean people, she sailed as an educational vessel until 2005.

https://www.loc.gov/resource/hhh.ma1719.sheet/?sp=1

150px grid, top deck is 33x8 
artwork by Tom Cartos, and Forgotten Adventures. 

![a ship at sea](https://i.imgur.com/1pgrVux.png)


![preview images](https://i.imgur.com/mxQhdCQ.png)